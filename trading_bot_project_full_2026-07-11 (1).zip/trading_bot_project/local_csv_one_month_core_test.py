# -*- coding: utf-8 -*-
"""
Local one-month core backtest using ONLY the attached real CSV file.
No API. No live fetches. No AI.

Purpose:
- Test the large project's core on one real month only.
- Use the project's own deterministic engines.
- Stay honest about invalidations / no-fills / actual fills.
"""

import datetime as dt
from dataclasses import dataclass
from zoneinfo import ZoneInfo

import pandas as pd

from authenticity_engine import AuthenticityEngine
from ict_math_engine import compute_mechanical_bias_anchor, find_recent_sweep
from ict_entry_checklist_engine import evaluate_all_entry_models
from human_trades_backtest import compute_trade_outcome
from core_alignment_bridge import order_status_allows_pending_order, order_status_executable_now, profit_usd_from_core_outcome
from ict_sessions import classify_session

UTC = ZoneInfo("UTC")
CSV = "/home/user/repo/data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv"
SYMBOL = "BTC/USDT"
MONTH_START = dt.datetime(2025, 8, 1, 0, 0, tzinfo=UTC)
MONTH_END = dt.datetime(2025, 9, 1, 0, 0, tzinfo=UTC)
ACCOUNT_BALANCE = 100.0
RISK_PCT = 0.01


def resample_ohlcv(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    out = (
        df.set_index("datetime")
        .resample(rule, label="right", closed="right")
        .agg({
            "open": "first",
            "high": "max",
            "low": "min",
            "close": "last",
            "volume": "sum",
        })
        .dropna()
        .reset_index()
    )
    out["ts"] = (out["datetime"].astype("int64") // 10**6).astype("int64")
    return out


@dataclass
class LocalDM:
    data_5m: dict
    data_15m: dict

    def get_ohlcv(self, symbol, timeframe, limit, output_format="dict"):
        if timeframe == "5m":
            return self.data_5m
        if timeframe == "15m":
            return self.data_15m
        raise ValueError(f"Unsupported timeframe for LocalDM: {timeframe}")


@dataclass
class LocalBrain:
    data_manager: LocalDM


class FrameView:
    def __init__(self, df: pd.DataFrame):
        self.df = df.reset_index(drop=True)
        self.ts = self.df["ts"].to_numpy()

    def slice_to_ts(self, current_ts: int, limit: int | None = None):
        idx = self.ts.searchsorted(current_ts, side="right")
        start = 0 if limit is None else max(0, idx - limit)
        sub = self.df.iloc[start:idx]
        if sub.empty:
            return None
        return {
            "timestamps": sub["ts"].tolist(),
            "opens": sub["open"].astype(float).tolist(),
            "highs": sub["high"].astype(float).tolist(),
            "lows": sub["low"].astype(float).tolist(),
            "closes": sub["close"].astype(float).tolist(),
            "volumes": sub["volume"].astype(float).tolist(),
            "count": len(sub),
        }


def main():
    print("=" * 90)
    print("LOCAL REAL-CSV TEST | LARGE PROJECT CORE | BTCUSDT | AUGUST 2025")
    print("No API. No AI. Source = attached CSV only.")
    print("=" * 90)

    df = pd.read_csv(CSV, parse_dates=["datetime"])
    df["datetime"] = pd.to_datetime(df["datetime"], utc=True)
    df = df.sort_values("datetime").reset_index(drop=True)
    df["ts"] = (df["datetime"].astype("int64") // 10**6).astype("int64")

    context_start = MONTH_START - dt.timedelta(days=120)
    full = df[(df["datetime"] >= context_start) & (df["datetime"] < MONTH_END)].copy()

    df5 = full.copy()
    df15 = resample_ohlcv(full, "15min")
    df4h = resample_ohlcv(full, "4h")
    df1d = resample_ohlcv(full, "1d")

    view5 = FrameView(df5)
    view15 = FrameView(df15)
    view4h = FrameView(df4h)
    view1d = FrameView(df1d)

    dm_5 = view5.slice_to_ts(int(MONTH_END.timestamp() * 1000), None)
    dm_15 = view15.slice_to_ts(int(MONTH_END.timestamp() * 1000), None)
    brain = LocalBrain(LocalDM(dm_5, dm_15))
    ae = AuthenticityEngine()

    month_start_ts = int(MONTH_START.timestamp() * 1000)
    month_end_ts = int(MONTH_END.timestamp() * 1000)

    account = ACCOUNT_BALANCE
    lock_until = None
    last_candidate_ts = None

    candidate_count = 0
    plan_count = 0
    ready_count = 0
    pending_rejected = 0
    invalidated_before_fill = 0
    never_hit = 0
    executed = []

    # نمشي على 15m داخل شهر آب فقط
    month_15 = df15[(df15["datetime"] >= MONTH_START) & (df15["datetime"] < MONTH_END)].copy().reset_index(drop=True)

    for _, row in month_15.iterrows():
        current_ts = int(row["ts"])

        if lock_until is not None and current_ts < lock_until:
            continue

        daily_data = view1d.slice_to_ts(current_ts, 200)
        if not daily_data or daily_data["count"] < 20:
            continue

        daily_bias_info = compute_mechanical_bias_anchor(daily_data, lookback=min(80, daily_data["count"]))
        daily_bias = daily_bias_info.get("anchor_direction")
        if daily_bias not in ("BULLISH", "BEARISH"):
            continue

        data15 = view15.slice_to_ts(current_ts, 250)
        if not data15 or data15["count"] < 80:
            continue

        sweep = find_recent_sweep(data15, is_long=(daily_bias == "BULLISH"), window=12)
        if not sweep:
            continue

        sweep_ts = data15["timestamps"][sweep["idx"]]
        # freshness: فقط لو السحب صار قريب فعلاً (آخر 30 دقيقة)
        if current_ts - sweep_ts > 30 * 60 * 1000:
            continue
        # cooldown بين sweepات متقاربة حتى ما نعدّ نفس الحركة مرتين
        if last_candidate_ts is not None and (sweep_ts - last_candidate_ts) < 8 * 3600 * 1000:
            continue

        candidate_count += 1
        last_candidate_ts = sweep_ts

        found_trade = False
        # نراقب 4 ساعات بعد السحب، شمعة 5m بشمعة
        for k in range(0, 48):
            sim_ts = sweep_ts + (k * 5 * 60 * 1000)
            if sim_ts >= month_end_ts:
                break

            sess = classify_session(sim_ts)
            if not sess.get("is_executable_window"):
                continue

            data5 = view5.slice_to_ts(sim_ts, 180)
            setup15 = view15.slice_to_ts(sim_ts, 180)
            h4 = view4h.slice_to_ts(sim_ts, 180)
            d1 = view1d.slice_to_ts(sim_ts, 180)
            if not data5 or not setup15 or not h4 or not d1:
                continue

            res = evaluate_all_entry_models(
                data5,
                daily_bias,
                htf_data_sources=[("1d", d1), ("4h", h4)],
                htf_major_data=d1,
                setup_tf_data=setup15,
                current_ts_ms=sim_ts,
                sweep_anchor={"timestamp": sweep_ts, "level": sweep["level"], "side": sweep.get("side")},
            )
            status = res.get("final_status")
            if status == "READY":
                ready_count += 1
            elif status == "PENDING_SETUP" and not order_status_allows_pending_order(res):
                pending_rejected += 1
            if not order_status_executable_now(res):
                continue

            chosen = res.get("chosen_model") or {}
            plan = chosen.get("plan") or {}
            entry = plan.get("entry")
            sl = plan.get("stop_loss")
            tp1 = plan.get("tp")
            model_name = chosen.get("model")
            if not (entry and sl and tp1):
                continue

            plan_count += 1
            is_short = daily_bias == "BEARISH"
            outcome = compute_trade_outcome(brain, SYMBOL, sim_ts, entry, sl, tp1, is_short)
            if not outcome:
                continue
            out_code = outcome.get("outcome")

            if out_code == "ORDER_INVALIDATED_BEFORE_FILL":
                invalidated_before_fill += 1
                continue
            if out_code == "ENTRY_NEVER_HIT":
                never_hit += 1
                continue
            if out_code in (None, "PENDING"):
                continue

            profit = profit_usd_from_core_outcome(outcome, entry, sl, balance=account, risk_pct=RISK_PCT)
            account += profit

            exit_time_ms = outcome.get("exit_time_ms") or outcome.get("final_exit_time")
            if exit_time_ms:
                lock_until = int(exit_time_ms)

            executed.append({
                "candidate_time": dt.datetime.fromtimestamp(sweep_ts / 1000, tz=UTC).strftime("%Y-%m-%d %H:%M"),
                "decision_time": dt.datetime.fromtimestamp(sim_ts / 1000, tz=UTC).strftime("%Y-%m-%d %H:%M"),
                "bias": daily_bias,
                "status": status,
                "model": model_name,
                "entry": float(entry),
                "sl": float(sl),
                "tp1": float(tp1),
                "outcome": out_code,
                "pnl_pct": float(outcome.get("pnl_pct", 0.0) or 0.0),
                "profit_usd": float(profit),
                "balance": float(account),
            })
            found_trade = True
            break

        # no else logging; we summarize globally

    print("\nSUMMARY")
    print("-" * 90)
    print(f"Month tested         : {MONTH_START.strftime('%Y-%m-%d')} -> {MONTH_END.strftime('%Y-%m-%d')} (August 2025)")
    print(f"Instrument           : {SYMBOL}")
    print(f"Data source          : local CSV only")
    print(f"Initial balance      : ${ACCOUNT_BALANCE:.2f}")
    print(f"Candidates found     : {candidate_count}")
    print(f"READY observations   : {ready_count}")
    print(f"Plans formed         : {plan_count}")
    print(f"Rejected pendings    : {pending_rejected}")
    print(f"Invalidated pre-fill : {invalidated_before_fill}")
    print(f"Entry never hit      : {never_hit}")
    print(f"Executed trades      : {len(executed)}")

    if executed:
        wins = sum(1 for x in executed if x["profit_usd"] > 0)
        losses = sum(1 for x in executed if x["profit_usd"] < 0)
        bes = sum(1 for x in executed if abs(x["profit_usd"]) < 1e-9)
        wr = (wins / (wins + losses) * 100.0) if (wins + losses) else 0.0
        pnl_pct = ((account - ACCOUNT_BALANCE) / ACCOUNT_BALANCE) * 100.0
        print(f"Wins                 : {wins}")
        print(f"Break-even           : {bes}")
        print(f"Losses               : {losses}")
        print(f"Win rate ex-BE       : {wr:.1f}%")
        print(f"Final balance        : ${account:.2f}")
        print(f"Net PnL              : {pnl_pct:+.2f}%")

        print("\nTRADES")
        print("-" * 90)
        for t in executed:
            print(
                f"{t['candidate_time']} | {t['bias']:<7} | {t['status']:<13} | {t['model']:<28} | "
                f"entry {t['entry']:.2f} | outcome {t['outcome']:<24} | pnl {t['profit_usd']:+.2f}$ | bal {t['balance']:.2f}$"
            )
    else:
        print("No executed trades for this month under this local-core test.")


if __name__ == "__main__":
    main()
