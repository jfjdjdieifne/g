# -*- coding: utf-8 -*-
"""Full READY-only month scan using local CSV and the large-project core only."""
import datetime as dt
from dataclasses import dataclass
from zoneinfo import ZoneInfo
import pandas as pd

from ict_math_engine import compute_mechanical_bias_anchor
from ict_entry_checklist_engine import evaluate_all_entry_models
from ict_sessions import classify_session
from human_trades_backtest import compute_trade_outcome
from core_alignment_bridge import order_status_executable_now, profit_usd_from_core_outcome

UTC = ZoneInfo("UTC")
CSV = "/home/user/repo/data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv"
SYMBOL = "BTC/USDT"
MONTH_START = dt.datetime(2025, 8, 1, 0, 0, tzinfo=UTC)
MONTH_END = dt.datetime(2025, 9, 1, 0, 0, tzinfo=UTC)
ACCOUNT_BALANCE = 100.0
RISK_PCT = 0.01


def resample_ohlcv(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    out = (
        df.set_index("datetime")
        .resample(rule, label="right", closed="right")
        .agg({"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"})
        .dropna()
        .reset_index()
    )
    out["ts"] = (out["datetime"].astype("int64") // 10**6).astype("int64")
    return out


class View:
    def __init__(self, df):
        self.df = df.reset_index(drop=True)
        self.ts = self.df["ts"].to_numpy()

    def s(self, current_ts, limit=None):
        idx = self.ts.searchsorted(current_ts, side="right")
        start = 0 if limit is None else max(0, idx - limit)
        sub = self.df.iloc[start:idx]
        if sub.empty:
            return None
        return {
            "timestamps": sub["ts"].tolist(),
            "opens": sub["open"].astype(float).tolist(),
            "highs": sub["high"].astype(float).tolist(),
            "lows": sub["low"].astype(float).tolist(),
            "closes": sub["close"].astype(float).tolist(),
            "volumes": sub["volume"].astype(float).tolist(),
            "count": len(sub),
        }


@dataclass
class LocalDM:
    data_5m: dict
    data_15m: dict
    def get_ohlcv(self, symbol, timeframe, limit, output_format="dict"):
        return self.data_5m if timeframe == "5m" else self.data_15m


@dataclass
class LocalBrain:
    data_manager: LocalDM


def main():
    print("=" * 90)
    print("LOCAL READY-ONLY SCAN | BTCUSDT | AUGUST 2025 | LARGE PROJECT CORE")
    print("=" * 90)
    df = pd.read_csv(CSV, parse_dates=["datetime"])
    df["datetime"] = pd.to_datetime(df["datetime"], utc=True)
    df = df.sort_values("datetime").reset_index(drop=True)
    df["ts"] = (df["datetime"].astype("int64") // 10**6).astype("int64")

    context_start = MONTH_START - dt.timedelta(days=120)
    full = df[(df["datetime"] >= context_start) & (df["datetime"] < MONTH_END)].copy()
    df5 = full.copy()
    df15 = resample_ohlcv(full, "15min")
    df4h = resample_ohlcv(full, "4h")
    df1d = resample_ohlcv(full, "1d")

    v5 = View(df5)
    v15 = View(df15)
    v4h = View(df4h)
    v1d = View(df1d)

    brain = LocalBrain(LocalDM(v5.s(int(MONTH_END.timestamp()*1000), None), v15.s(int(MONTH_END.timestamp()*1000), None)))

    month5 = df5[(df5["datetime"] >= MONTH_START) & (df5["datetime"] < MONTH_END)].copy().reset_index(drop=True)

    account = ACCOUNT_BALANCE
    lock_until = None
    ready_observations = 0
    executed = []

    for _, row in month5.iterrows():
        current_ts = int(row["ts"])
        if lock_until is not None and current_ts < lock_until:
            continue
        sess = classify_session(current_ts)
        if not sess.get("is_executable_window"):
            continue

        d1 = v1d.s(current_ts, 200)
        h4 = v4h.s(current_ts, 200)
        s15 = v15.s(current_ts, 200)
        d5 = v5.s(current_ts, 200)
        if not d1 or not h4 or not s15 or not d5:
            continue
        if d1["count"] < 20 or d5["count"] < 50:
            continue

        daily_bias = compute_mechanical_bias_anchor(d1, lookback=min(80, d1["count"])).get("anchor_direction")
        if daily_bias not in ("BULLISH", "BEARISH"):
            continue

        res = evaluate_all_entry_models(
            d5,
            daily_bias,
            htf_data_sources=[("1d", d1), ("4h", h4)],
            htf_major_data=d1,
            setup_tf_data=s15,
            current_ts_ms=current_ts,
        )
        if not order_status_executable_now(res):
            continue

        ready_observations += 1
        chosen = res.get("chosen_model") or {}
        plan = chosen.get("plan") or {}
        entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
        if not (entry and sl and tp1):
            continue

        outcome = compute_trade_outcome(brain, SYMBOL, current_ts, entry, sl, tp1, daily_bias == "BEARISH")
        if not outcome or outcome.get("outcome") in (None, "PENDING", "ENTRY_NEVER_HIT", "ORDER_INVALIDATED_BEFORE_FILL"):
            continue

        profit = profit_usd_from_core_outcome(outcome, entry, sl, balance=account, risk_pct=RISK_PCT)
        account += profit
        exit_time_ms = outcome.get("exit_time_ms") or outcome.get("final_exit_time")
        if exit_time_ms:
            lock_until = int(exit_time_ms)

        executed.append({
            "time": dt.datetime.fromtimestamp(current_ts/1000, tz=UTC).strftime('%Y-%m-%d %H:%M'),
            "bias": daily_bias,
            "model": chosen.get("model"),
            "entry": float(entry),
            "outcome": outcome.get("outcome"),
            "profit_usd": float(profit),
            "balance": float(account),
        })

    print(f"READY observations : {ready_observations}")
    print(f"Executed trades    : {len(executed)}")
    if executed:
        wins = sum(1 for x in executed if x['profit_usd'] > 0)
        losses = sum(1 for x in executed if x['profit_usd'] < 0)
        bes = sum(1 for x in executed if abs(x['profit_usd']) < 1e-9)
        print(f"Wins/BE/Losses    : {wins}/{bes}/{losses}")
        print(f"Final balance     : ${account:.2f} ({((account-ACCOUNT_BALANCE)/ACCOUNT_BALANCE)*100:+.2f}%)")
        print("TRADES")
        for t in executed:
            print(f"{t['time']} | {t['bias']} | {t['model']} | {t['outcome']} | {t['profit_usd']:+.2f}$ | {t['balance']:.2f}$")
    else:
        print("No executed READY trades found in this month scan.")


if __name__ == '__main__':
    main()
