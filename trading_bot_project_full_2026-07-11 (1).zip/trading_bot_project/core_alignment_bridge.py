# -*- coding: utf-8 -*-
"""
Bridge layer to unify auxiliary scripts with the project's canonical core.

المبدأ:
- لا يفرض قواعد جديدة من خارج المشروع.
- فقط يعبّر برمجياً عن المعاني الموجودة أصلاً داخل النواة:
  * READY = قابل للتنفيذ الآن
  * PENDING_SETUP = صالح كفكرة/أمر معلّق إذا كانت السكربت نفسها تحاكي
    lifecycle أمر limit تاريخي، لكنه ليس market execution فوري.
  * الربح/الخسارة يُشتقان من `compute_trade_outcome()` الرسمي، لا من
    معادلات قديمة 80/20 أو صيغ محلية متفرقة.
"""

from __future__ import annotations


_LIMIT_PENDING_ALLOWED = {
    # هذه البنود لا تعني أن الفكرة فشلت؛ بل أن السياق/التوقيت أو
    # تأكيد الفريم الأدنى لم يأتِ بعد. يمكن إبقاء الخطة كأمر limit
    # تاريخي/معلّق فقط، لا تنفيذ سوقي فوري.
    "ACTIVE_KILL_ZONE_TIMING",
    "LTF_CONFIRMATION_CHOCH_OR_BOS",
    "LTF_BOS_CONFIRMS",
    "HTF_CONTEXT_AT_PD_ARRAY",
}

# هذه البنود تعني أن بنية الإعداد نفسها لم تكتمل بعد. القبول بها كأنها
# أوامر قابلة للتنفيذ هو أصل التخبيص الذي كشفه اختبار CSV المحلي.
_STRUCTURAL_PENDING_BLOCKERS = {
    "DISPLACEMENT_AFTER_SWEEP",
    "FVG_FROM_DISPLACEMENT",
    "MANIPULATION_OCCURRED",
    "DISTRIBUTION_CONFIRMED",
    "FVG_CREATED",
    "FIRST_STRUCTURAL_RESPONSE",
    "MAJOR_HTF_LEVEL",
}


def _extract_pending_condition_names(result_or_status) -> set[str]:
    if not isinstance(result_or_status, dict):
        return set()
    chosen = result_or_status.get("chosen_model") or {}
    conditions = chosen.get("conditions") or []
    return {c.get("name") for c in conditions if c.get("status") == "PENDING" and c.get("name")}



def order_status_allows_pending_order(result_or_status) -> bool:
    """
    يستخدم فقط في السكربتات التي تحاكي order lifecycle تاريخي.

    منطق ICT الصحيح ليس "كل PENDING صالح" ولا "كل PENDING مرفوض".
    بل:
    - READY: صالح دائماً.
    - PENDING_SETUP: صالح فقط إذا كان الـpending من نوع تأكيد سياقي/
      توقيتي، لا من نوع بنية لم تتشكل بعد.
    """
    status = result_or_status.get("final_status") if isinstance(result_or_status, dict) else result_or_status
    if status == "READY":
        return True
    if status != "PENDING_SETUP":
        return False
    pending_names = _extract_pending_condition_names(result_or_status)
    if not pending_names:
        return True
    if pending_names & _STRUCTURAL_PENDING_BLOCKERS:
        return False
    return pending_names.issubset(_LIMIT_PENDING_ALLOWED)



def order_status_executable_now(result_or_status) -> bool:
    """للتنفيذ الفوري فقط - لا يقبل إلا READY."""
    status = result_or_status.get("final_status") if isinstance(result_or_status, dict) else result_or_status
    return status == "READY"



def risk_amount_from_balance(balance: float, risk_pct: float) -> float:
    return float(balance) * float(risk_pct)



def position_notional_from_entry_sl(entry: float, sl: float, risk_amount: float) -> float:
    sl_dist_pct = abs(float(entry) - float(sl)) / float(entry)
    if sl_dist_pct <= 0:
        return 0.0
    pos_size_units = float(risk_amount) / sl_dist_pct / float(entry)
    return pos_size_units * float(entry)



def profit_usd_from_core_outcome(outcome: dict, entry: float, sl: float,
                                 *, risk_amount: float | None = None,
                                 balance: float | None = None,
                                 risk_pct: float | None = None) -> float:
    """
    يشتق الربح بالدولار من outcome الرسمي:
    - outcome['pnl_pct'] صادر من compute_trade_outcome() الموحَّد
    - يطبَّق على position notional المشتق من entry/sl/risk
    """
    if outcome is None:
        return 0.0
    if risk_amount is None:
        if balance is None or risk_pct is None:
            raise ValueError("Provide either risk_amount or (balance and risk_pct).")
        risk_amount = risk_amount_from_balance(balance, risk_pct)
    notional = position_notional_from_entry_sl(entry, sl, risk_amount)
    pnl_pct = float(outcome.get("pnl_pct", outcome.get("pnl_pct_blended", 0.0)) or 0.0)
    return (pnl_pct / 100.0) * notional



def outcome_display_label(outcome_code: str) -> str:
    mapping = {
        "TP1_THEN_BE": "ربح جزئي + Runner 50/50 🎯",
        "PARTIAL_TP_HIT_THEN_OPEN": "ربح جزئي + Runner 50/50 🎯",
        "SL_HIT": "ضرب ستوب لوس ❌",
        "BREAK_EVEN_HIT": "خروج على الدخول 🛡️",
        "DYNAMIC_TRAIL_HIT": "تتبّع هيكلي / Runner 🧠🎯",
        "OPEN": "ما زالت مفتوحة ⏳",
        "ENTRY_NEVER_HIT": "لم تتفعل ⏳",
        "ORDER_INVALIDATED_BEFORE_FILL": "أُبطلت قبل التفعيل ⛔",
    }
    return mapping.get(outcome_code, outcome_code)
