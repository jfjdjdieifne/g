import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
from human_trades_backtest import compute_trade_outcome
from core_alignment_bridge import order_status_allows_pending_order, outcome_display_label, profit_usd_from_core_outcome

brain = BrainCore()
ae = AuthenticityEngine()
SYMBOL = "ETH/USDT"
ACCOUNT_BALANCE = 100.0
RISK_USD = ACCOUNT_BALANCE * 0.01

print("جاري تشغيل محرك البحث العميق لاكتشاف الفرص الحقيقية عبر 6 أشهر...")
full_data = brain.data_manager.get_ohlcv(SYMBOL, "15m", 16000, output_format="dict")
n = len(full_data["closes"])

candidates = []
already_reported = set()

for i in range(1000, n, 4): # مسح أكثر دقة (كل شمعة تقريبا)
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }

    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=100)
    except Exception:
        continue
    daily_bias = anchor.get("anchor_direction")
    if daily_bias not in ("BULLISH", "BEARISH"):
        continue

    try:
        # قمت بتقليل الشروط ليلتقط عدد كبير جداً من السوينغات
        sig = ae.detect_significant_swings(window_data, swing_window=1, lookback_candles=100)
    except Exception:
        continue

    current_ts = window_data["timestamps"][-1]

    if daily_bias == "BULLISH":
        important_levels = [s for s in sig.get("all_lows_tiered", [])]
        for candidate in important_levels:
            level_price = candidate["price"]
            res = classify_sweep_or_run(window_data, level_price, level_is_high=False, check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -5:
                if not any(abs(c["timestamp"] - current_ts) < 6*3600*1000 for c in candidates):
                    dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                    candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "mechanical_bias": daily_bias})
                    break
    else:
        important_levels = [s for s in sig.get("all_highs_tiered", [])]
        for candidate in important_levels:
            level_price = candidate["price"]
            res = classify_sweep_or_run(window_data, level_price, level_is_high=True, check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -5:
                if not any(abs(c["timestamp"] - current_ts) < 6*3600*1000 for c in candidates):
                    dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                    candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "mechanical_bias": daily_bias})
                    break

candidates.sort(key=lambda c: c["timestamp"])
if len(candidates) > 35:
    candidates = candidates[-35:]
    
print(f"تم التقاط {len(candidates)} إشارة سحب سيولة لعمل المحاكاة.")

results = []
account = ACCOUNT_BALANCE

for idx, cand in enumerate(candidates):
    sweep_ts = cand['timestamp']
    bias = cand['mechanical_bias']
    dt_str = cand['datetime_utc']
    
    found_trade = False
    for k in range(0, 48):
        sim_ts = sweep_ts + (k * 5 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if order_status_allows_pending_order(res):
                chosen = res.get("chosen_model", {})
                plan = chosen.get("plan", {})
                entry = plan.get("entry")
                sl = plan.get("stop_loss")
                tp1 = plan.get("tp")
                
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    outcome = compute_trade_outcome(brain, SYMBOL, sim_ts, entry, sl, tp1, is_short)
                    if outcome and outcome.get("outcome") != "PENDING":
                        out_code = outcome.get("outcome")
                        
                        sl_dist_pct = abs(entry - sl) / entry
                        pos_size_usd = RISK_USD / sl_dist_pct if sl_dist_pct > 0 else 0
                        
                        profit_usd = (outcome.get("pnl_pct", 0.0) / 100.0) * pos_size_usd
                            
                        account += profit_usd
                        results.append({
                            "num": idx+1,
                            "date": dt_str,
                            "bias": bias,
                            "outcome": out_code,
                            "profit": profit_usd,
                            "balance": account
                        })
                        found_trade = True
                        break
        except Exception:
            pass

print("\n" + "="*80)
for r in results:
    out_label = r['outcome']
    if out_label in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]: out_label = "ربح جزئي + Runner 50/50 🎯"
    elif out_label == "SL_HIT": out_label = "ضرب ستوب ❌"
    elif out_label == "BREAK_EVEN_HIT": out_label = "خروج عالدخول 🛡️"
    elif out_label == "ORDER_INVALIDATED_BEFORE_FILL": out_label = "ملغية 🚫"
    elif out_label == "ENTRY_NEVER_HIT": out_label = "لم تتفعل ⏳"
    
    print(f"الصفقة [{r['num']:02d}] {r['date']} | {r['bias']} | النتيجة: {out_label} | الربح: {r['profit']:>5.2f}$ | الرصيد: {r['balance']:.2f}$")

print(f"\nعدد الصفقات الإجمالي المنفذة: {len(results)}")
print(f"الرصيد النهائي: {account:.2f}$")
print("="*80)
