# -*- coding: utf-8 -*-
"""
Core regression suite for the large ICT project.

الهدف: اختبار كل دوال الـcore الأساسية فعلياً، مع الاعتماد على نفس
دستور المشروع المحلي ومنطق مايكل الموثّق داخله، لا قواعد مخترعة.

ملاحظة مهمة:
- هذه suite تركّز على core functions (المحركات الجوهرية) + smoke tests
  للدوال الأعلى تعقيداً.
- لا تستخدم أي API حي ولا أي شبكة.
"""
import math
import sys
import datetime
from zoneinfo import ZoneInfo

BASE = "/home/user/repo/extracted/test/extracted/trading_bot_project"
if BASE not in sys.path:
    sys.path.insert(0, BASE)

from ict_math_engine import (
    _atr, compute_displacement, detect_fair_value_gaps, _compute_fill_pct,
    detect_order_blocks, _count_retests, classify_sweep_or_run, find_recent_sweep,
    detect_judas_swing, detect_mss, compute_mechanical_bias_anchor,
    compute_premium_discount, find_structural_sl_anchors, detect_equal_highs_lows,
    find_tp_targets, simulate_managed_trade_outcome, compute_opposing_break_context,
    compute_structural_break_quality_score, classify_break_reversal_authenticity,
    check_order_invalidated_before_fill, detect_breaker_block_opportunity,
    classify_htf_structural_challenge,
)
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import (
    _build_plan_with_tp1_tp2, _min_sl_buffer, _last_atr,
    evaluate_model_a, evaluate_model_b, evaluate_model_c,
    evaluate_model_d, evaluate_model_e, evaluate_model_f,
    evaluate_generic_structural_fallback, evaluate_all_entry_models,
)
from ict_sessions import ts_to_ny, _minutes_since_midnight, classify_session, compute_overnight_range, session_prose
from human_trades_backtest import compute_trade_outcome

NY = ZoneInfo("America/New_York")
UTC = ZoneInfo("UTC")

PASSED = 0
FAILED = 0


def ok(name, condition, detail=""):
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"✅ {name}" + (f" — {detail}" if detail else ""))
    else:
        FAILED += 1
        print(f"❌ {name}" + (f" — {detail}" if detail else ""))
        raise AssertionError(name + (": " + detail if detail else ""))


def mk_data(opens, highs, lows, closes, volumes=None, start_ts=None, step_min=5):
    if start_ts is None:
        start_ts = int(datetime.datetime(2025, 9, 8, 13, 0, tzinfo=UTC).timestamp() * 1000)
    n = len(closes)
    if volumes is None:
        volumes = [100 + i * 3 for i in range(n)]
    return {
        "timestamps": [start_ts + i * step_min * 60 * 1000 for i in range(n)],
        "opens": list(map(float, opens)),
        "highs": list(map(float, highs)),
        "lows": list(map(float, lows)),
        "closes": list(map(float, closes)),
        "volumes": list(map(float, volumes)),
        "count": n,
    }


def mk_from_closes(closes, start_ts=None, step_min=5, wick=0.6):
    opens = [closes[0]] + closes[:-1]
    highs = [max(o, c) + wick for o, c in zip(opens, closes)]
    lows = [min(o, c) - wick for o, c in zip(opens, closes)]
    return mk_data(opens, highs, lows, closes, start_ts=start_ts, step_min=step_min)


# ─────────────────────────────────────────────────────────────
# Synthetic datasets
# ─────────────────────────────────────────────────────────────
trend_up = mk_from_closes([
    100, 101, 102, 101.5, 103, 104.5, 104, 105.5, 107, 106.5,
    108, 109.5, 109, 111, 112.5, 112, 114, 115.5, 115, 117,
])

trend_down = mk_from_closes([
    117, 116, 115, 115.5, 114, 113, 113.5, 112, 111, 111.5,
    110, 109, 109.5, 108, 107, 107.5, 106, 105, 105.5, 104,
])

fvg_bull = mk_data(
    opens=[100.0, 100.4, 104.5, 105.5, 106.2, 106.8, 106.9, 107.2, 107.0, 107.4],
    highs=[101.0, 105.0, 107.8, 108.0, 107.2, 107.5, 107.6, 107.7, 107.8, 108.2],
    lows=[99.6, 100.0, 102.0, 104.7, 105.8, 106.1, 106.4, 106.7, 106.8, 107.0],
    closes=[100.4, 104.6, 107.1, 106.2, 106.8, 107.0, 107.3, 107.1, 107.5, 108.0],
)

fvg_bear = mk_data(
    opens=[107.0, 106.7, 102.2, 101.8, 101.0, 100.6, 100.4, 100.0, 99.8, 99.6],
    highs=[107.4, 107.0, 105.8, 102.0, 101.4, 101.0, 100.9, 100.5, 100.2, 99.9],
    lows=[106.5, 102.5, 100.2, 100.0, 99.8, 99.5, 99.3, 99.0, 98.8, 98.6],
    closes=[106.7, 102.6, 100.4, 101.0, 100.6, 99.9, 99.8, 99.6, 99.3, 99.0],
)

sweep_long = mk_data(
    opens=[102.0, 101.7, 101.2, 100.8, 101.0, 102.2],
    highs=[102.5, 102.0, 101.4, 101.5, 102.4, 103.0],
    lows=[101.4, 100.8, 100.3, 99.4, 100.7, 101.7],
    closes=[101.8, 101.1, 100.7, 101.3, 102.1, 102.8],
)

sweep_short = mk_data(
    opens=[100.0, 100.4, 100.8, 101.2, 101.0, 99.8],
    highs=[100.6, 101.0, 101.5, 102.6, 101.3, 100.1],
    lows=[99.6, 100.2, 100.5, 100.9, 99.7, 99.2],
    closes=[100.3, 100.8, 101.2, 100.7, 99.9, 99.4],
)

# repeated equal highs around 110
base_eq = mk_data(
    opens=[106,108,109,108.8,109.1,108.9,109.2,108.7,109.0,108.8],
    highs=[108,110.00,109.2,110.18,109.4,110.05,109.3,110.12,109.1,108.9],
    lows=[105.5,107.2,108.4,108.1,108.6,108.2,108.8,108.0,108.5,108.2],
    closes=[107.8,109.0,108.9,109.1,108.95,109.0,108.92,109.0,108.88,108.6],
)

# Monday 09:00 NY timestamps for session-sensitive models
monday_9_ny = int(datetime.datetime(2025, 9, 8, 9, 0, tzinfo=NY).astimezone(UTC).timestamp() * 1000)
session_data = mk_from_closes([
    100,100.2,100.4,100.3,100.1,99.8,99.6,99.9,100.5,101.2,
    101.0,100.8,101.4,101.8,102.1,101.9,102.4,102.8,103.1,103.0,
], start_ts=monday_9_ny, step_min=5)

# ─────────────────────────────────────────────────────────────
# ict_math_engine
# ─────────────────────────────────────────────────────────────
atr = _atr(trend_up["highs"], trend_up["lows"], trend_up["closes"])
ok("ict_math_engine._atr", len(atr) == len(trend_up["closes"]) and max(atr) > 0)

disp = compute_displacement(fvg_bull, lookback=6)
ok("ict_math_engine.compute_displacement", isinstance(disp, dict) and "displacement_candles" in disp)

bull_fvgs = detect_fair_value_gaps(fvg_bull, lookback=10, require_displacement=False)
ok("ict_math_engine.detect_fair_value_gaps bullish", len(bull_fvgs["bullish_fvgs"]) >= 1)

bear_fvgs = detect_fair_value_gaps(fvg_bear, lookback=10, require_displacement=False)
ok("ict_math_engine.detect_fair_value_gaps bearish", len(bear_fvgs["bearish_fvgs"]) >= 1)

fill_pct = _compute_fill_pct(fvg_bull["lows"], 2, len(fvg_bull["lows"]), 102.0, 101.0, True)
ok("ict_math_engine._compute_fill_pct", 0 <= fill_pct <= 100)

obs = detect_order_blocks(fvg_bull, lookback=6)
ok("ict_math_engine.detect_order_blocks", isinstance(obs, dict) and "bullish_obs" in obs and "bearish_obs" in obs)

retests = _count_retests(fvg_bull["lows"], fvg_bull["highs"], 0, len(fvg_bull["lows"]), 105.0, 101.0)
ok("ict_math_engine._count_retests", isinstance(retests, int) and retests >= 0)

sweep_res_long = classify_sweep_or_run(sweep_long, 100.0, level_is_high=False)
ok("ict_math_engine.classify_sweep_or_run long sweep", sweep_res_long.get("classification") == "GENUINE_REVERSAL_SWEEP")

sweep_res_short = classify_sweep_or_run(sweep_short, 102.0, level_is_high=True)
ok("ict_math_engine.classify_sweep_or_run short sweep", sweep_res_short.get("classification") == "GENUINE_REVERSAL_SWEEP")

recent_sweep = find_recent_sweep(sweep_long, is_long=True, window=6)
ok("ict_math_engine.find_recent_sweep", recent_sweep is None or isinstance(recent_sweep, dict))

overnight = {
    "found": True,
    "range_high": 101.5,
    "range_low": 99.5,
    "range_start_ts": session_data["timestamps"][0],
    "range_end_ts": session_data["timestamps"][min(5, len(session_data["timestamps"]) - 1)],
}
judas = detect_judas_swing(session_data, "BULLISH", overnight)
ok("ict_math_engine.detect_judas_swing", isinstance(judas, dict))

mss = detect_mss(trend_up, swing_window=2)
ok("ict_math_engine.detect_mss", isinstance(mss, dict) and "breaks_found" in mss)

bias_anchor = compute_mechanical_bias_anchor(trend_up, lookback=20)
ok("ict_math_engine.compute_mechanical_bias_anchor", bias_anchor.get("anchor_direction") in {"BULLISH", "BEARISH", "UNKNOWN", "MIXED", "UNCLEAR"})

pd_bull = compute_premium_discount(100000, 102000, 100900, is_bullish_setup=True)
pd_bear = compute_premium_discount(100000, 102000, 101100, is_bullish_setup=False)
ok("ict_math_engine.compute_premium_discount bullish", pd_bull.get("zone") in {"DISCOUNT", "AT_EQUILIBRIUM", "PREMIUM"})
ok("ict_math_engine.compute_premium_discount bearish", pd_bear.get("zone") in {"DISCOUNT", "AT_EQUILIBRIUM", "PREMIUM"})

sl_anchors_long = find_structural_sl_anchors(trend_up, is_long=True, reference_price=trend_up["closes"][-1])
ok("ict_math_engine.find_structural_sl_anchors long", isinstance(sl_anchors_long.get("anchors"), list))
if sl_anchors_long.get("anchors"):
    ok("ict_math_engine.find_structural_sl_anchors long side", all(a["price"] < trend_up["closes"][-1] for a in sl_anchors_long["anchors"]))

sl_anchors_short = find_structural_sl_anchors(trend_down, is_long=False, reference_price=trend_down["closes"][-1])
ok("ict_math_engine.find_structural_sl_anchors short", isinstance(sl_anchors_short.get("anchors"), list))
if sl_anchors_short.get("anchors"):
    ok("ict_math_engine.find_structural_sl_anchors short side", all(a["price"] > trend_down["closes"][-1] for a in sl_anchors_short["anchors"]))

eqs = detect_equal_highs_lows(base_eq, swing_window=1, tolerance_pct=0.003, lookback=10)
ok("ict_math_engine.detect_equal_highs_lows", isinstance(eqs, dict) and "eqh_clusters" in eqs and len(eqs["eqh_clusters"]) >= 1)

targets = find_tp_targets(trend_up, entry_price=108.0, sl_price=106.0, is_long=True, lookback=20)
ok("ict_math_engine.find_tp_targets", isinstance(targets, dict) and "tp1" in targets and "tp2" in targets)
if targets.get("tp1"):
    ok("ict_math_engine.find_tp_targets direction", targets["tp1"]["price"] > 108.0)

managed = simulate_managed_trade_outcome(
    mk_data(
        opens=[100,100,101,104,103,102],
        highs=[100.5,101.2,104.5,106.0,104.0,103.0],
        lows=[99.5,99.8,100.5,103.2,101.8,101.0],
        closes=[100.0,101.0,104.0,103.6,102.2,101.4],
    ),
    entry_price=100.0,
    sl_price=98.0,
    tp1_price=104.0,
    tp2_info={"mode": "OPEN_TRAILING", "detail": "runner"},
    is_short=False,
)
ok("ict_math_engine.simulate_managed_trade_outcome", managed.get("classification") in {"WIN_TRAIL", "WIN_PARTIAL", "OPEN_AFTER_TP1", "WIN_FULL", "LOSS", "NEITHER_HIT_WITHIN_WINDOW"})

break_event = {"direction": "BULLISH", "break_candle_index_from_end": -2, "broken_level": 110.0, "displacement_confirmed": True, "prior_sweep": {"genuine_reversal_sweep": True}}
opp = compute_opposing_break_context(trend_up, break_event)
ok("ict_math_engine.compute_opposing_break_context", isinstance(opp, dict))

quality = compute_structural_break_quality_score(trend_up, break_event)
ok("ict_math_engine.compute_structural_break_quality_score", isinstance(quality, dict) and "quality_rating" in quality)

auth_hi = classify_break_reversal_authenticity({"displacement_confirmed": True, "prior_sweep": {"genuine_reversal_sweep": True}}, tier="MAJOR")
auth_lo = classify_break_reversal_authenticity({"displacement_confirmed": False, "prior_sweep": {"genuine_reversal_sweep": False}}, tier="MINOR")
ok("ict_math_engine.classify_break_reversal_authenticity high", auth_hi.get("verdict") in {"MAJOR_STRUCTURAL_BREAK", "CONFIRMED_REVERSAL_HIGH_CONVICTION", "PARTIALLY_CONFIRMED_DEVELOPING", "UNCONFIRMED_LIKELY_INDUCEMENT"})
ok("ict_math_engine.classify_break_reversal_authenticity low", auth_lo.get("verdict") in {"MAJOR_STRUCTURAL_BREAK", "CONFIRMED_REVERSAL_HIGH_CONVICTION", "PARTIALLY_CONFIRMED_DEVELOPING", "UNCONFIRMED_LIKELY_INDUCEMENT"})

invalid = check_order_invalidated_before_fill(
    highs=[101, 101.5, 102], lows=[99.5, 99.8, 100], closes=[100.8, 99.0, 101.0], opens=[100.2, 100.7, 100.9],
    timestamps=[1, 2, 3], start_idx=0, entry_idx=None, sl_price=99.5, is_long=True,
)
ok("ict_math_engine.check_order_invalidated_before_fill", invalid.get("invalidated") is True)

breaker = detect_breaker_block_opportunity(trend_up, invalidation_idx=3, sl_price=99.0, is_long=True)
ok("ict_math_engine.detect_breaker_block_opportunity", isinstance(breaker, dict) and "classification" in breaker)

htf_challenge = classify_htf_structural_challenge(trend_down, "BULLISH", lookback=20)
ok("ict_math_engine.classify_htf_structural_challenge", htf_challenge.get("classification") in {"REAL_REVERSAL_CONFIRMED", "DEVELOPING_CHALLENGE", "LIKELY_CORRECTION_ONLY", "NO_CHALLENGE"})

# ─────────────────────────────────────────────────────────────
# authenticity_engine.AuthenticityEngine
# ─────────────────────────────────────────────────────────────
ae = AuthenticityEngine()

br = ae.breakout_authenticity_score(trend_up, level_price=110.0, direction="BULLISH")
ok("AuthenticityEngine.breakout_authenticity_score", isinstance(br, dict) and "verdict" in br and "score" in br)

cls = ae.classify_sweep(sweep_long, swing_price=100.0, sweep_index=3, direction="BULLISH")
ok("AuthenticityEngine.classify_sweep", isinstance(cls, dict) and "classification" in cls)

mrs = ae.detect_most_recent_sweep(sweep_long)
ok("AuthenticityEngine.detect_most_recent_sweep", isinstance(mrs, dict))

sig_swings = ae.detect_significant_swings(trend_up)
ok("AuthenticityEngine.detect_significant_swings", isinstance(sig_swings, dict) and "all_highs_tiered" in sig_swings)

seq = ae.compute_structure_sequence(trend_up)
ok("AuthenticityEngine.compute_structure_sequence", isinstance(seq, dict))

val_ob = ae.validate_order_block(trend_up, ob_index=5, ob_top=106.0, ob_bottom=103.0, direction="BULLISH")
ok("AuthenticityEngine.validate_order_block", isinstance(val_ob, dict))

trap = ae.trapped_trader_evidence(trend_up, swing_index=5, direction="BULLISH")
ok("AuthenticityEngine.trapped_trader_evidence", isinstance(trap, dict))

vol_auth = ae.check_volume_authenticity(trend_up)
ok("AuthenticityEngine.check_volume_authenticity", isinstance(vol_auth, dict))

audit_prices = ae.audit_signal_prices({"signal": "BUY_LIMIT", "entry": 108.0, "stop_loss": 106.0, "tp": 111.0}, trend_up)
ok("AuthenticityEngine.audit_signal_prices", isinstance(audit_prices, dict))

bos = ae.detect_most_recent_bos(trend_up)
ok("AuthenticityEngine.detect_most_recent_bos", isinstance(bos, dict))

ob_for_disp = ae._find_order_block_for_displacement(trend_up, displacement_index=len(trend_up["closes"]) - 2, direction="BULLISH")
ok("AuthenticityEngine._find_order_block_for_displacement", ob_for_disp is None or isinstance(ob_for_disp, dict))

fvg_for_disp = ae._find_fvg_near_displacement(fvg_bull, displacement_index=2, direction="BULLISH")
ok("AuthenticityEngine._find_fvg_near_displacement", fvg_for_disp is None or isinstance(fvg_for_disp, dict))

chain = ae.build_causal_derivation_chain(trend_up)
ok("AuthenticityEngine.build_causal_derivation_chain", isinstance(chain, dict))

xcheck = ae.cross_check_bos_reconciliation({"reasoning": "BOS above 110 confirmed"}, trend_up)
ok("AuthenticityEngine.cross_check_bos_reconciliation", isinstance(xcheck, dict))

last_candle = ae.audit_last_candle_report({"reasoning": "last candle bullish close 117"}, trend_up)
ok("AuthenticityEngine.audit_last_candle_report", isinstance(last_candle, dict))

sel_wick = ae.detect_selective_wick_citation({"reasoning": "wick rejection observed"}, trend_up)
ok("AuthenticityEngine.detect_selective_wick_citation", isinstance(sel_wick, dict))

num_cmp = ae.audit_numeric_comparison_claims("price moved above 110 then below 112 while remaining above 108")
ok("AuthenticityEngine.audit_numeric_comparison_claims", isinstance(num_cmp, dict))

anchor_consistency = ae.audit_bias_anchor_consistency("BULLISH", "bullish due to recent break", bias_anchor, trend_up)
ok("AuthenticityEngine.audit_bias_anchor_consistency", isinstance(anchor_consistency, dict))

sl_struct = ae.audit_sl_is_structural(108.0, 106.0, True, trend_up)
ok("AuthenticityEngine.audit_sl_is_structural", isinstance(sl_struct, dict))

struct_labels = ae.audit_structure_labels("swing high 117 and swing low 100", trend_up)
ok("AuthenticityEngine.audit_structure_labels", isinstance(struct_labels, dict))

atr2 = ae._atr(trend_up["highs"], trend_up["lows"], trend_up["closes"])
ok("AuthenticityEngine._atr", len(atr2) == len(trend_up["closes"]))

round_num = ae._is_round_number(100.0)
ok("AuthenticityEngine._is_round_number", isinstance(round_num, bool))

smt = ae.detect_smt_divergence(trend_up, trend_down, label_a="BTC", label_b="ETH")
ok("AuthenticityEngine.detect_smt_divergence", isinstance(smt, dict) and "checked" in smt)

report = ae.build_authenticity_report(trend_up)
ok("AuthenticityEngine.build_authenticity_report", isinstance(report, dict))

# ─────────────────────────────────────────────────────────────
# ict_entry_checklist_engine
# ─────────────────────────────────────────────────────────────
plan_targets = _build_plan_with_tp1_tp2(trend_up, 108.0, 106.0, True, "test", htf_data_sources=[("1d", trend_up)])
ok("ict_entry_checklist_engine._build_plan_with_tp1_tp2", plan_targets is None or isinstance(plan_targets, dict))

sl_buffer = _min_sl_buffer(100.0, 1.5)
ok("ict_entry_checklist_engine._min_sl_buffer", sl_buffer > 0)

latr = _last_atr(trend_up)
ok("ict_entry_checklist_engine._last_atr", latr >= 0)

allowed_status = {"DISQUALIFIED", "PENDING_SETUP", "READY", "NO_CANDIDATE", "NO_MODEL_QUALIFIES"}

for fn_name, fn in [
    ("evaluate_model_a", evaluate_model_a),
    ("evaluate_model_b", lambda d, b: evaluate_model_b(d, b, setup_tf_data=session_data)),
    ("evaluate_model_c", evaluate_model_c),
    ("evaluate_model_d", evaluate_model_d),
    ("evaluate_model_e", evaluate_model_e),
    ("evaluate_model_f", lambda d, b: evaluate_model_f(d, b, htf_major_data=trend_up)),
    ("evaluate_generic_structural_fallback", evaluate_generic_structural_fallback),
]:
    try:
        res = fn(session_data, "BULLISH")
        ok(f"ict_entry_checklist_engine.{fn_name}", isinstance(res, dict) and res.get("status") in allowed_status)
    except TypeError:
        res = fn(session_data, "BULLISH")
        ok(f"ict_entry_checklist_engine.{fn_name}", isinstance(res, dict) and res.get("status") in allowed_status)

all_models = evaluate_all_entry_models(session_data, "BULLISH", htf_data_sources=[("4h", trend_up)], htf_major_data=trend_up, setup_tf_data=session_data)
ok("ict_entry_checklist_engine.evaluate_all_entry_models", isinstance(all_models, dict) and all_models.get("final_status") in {"READY", "PENDING_SETUP", "NO_MODEL_QUALIFIES"})

# ─────────────────────────────────────────────────────────────
# ict_sessions
# ─────────────────────────────────────────────────────────────
mon_ts = int(datetime.datetime(2025, 9, 8, 9, 0, tzinfo=NY).astimezone(UTC).timestamp() * 1000)
sat_ts = int(datetime.datetime(2025, 9, 6, 9, 0, tzinfo=NY).astimezone(UTC).timestamp() * 1000)

ny_dt = ts_to_ny(mon_ts)
ok("ict_sessions.ts_to_ny", ny_dt.tzinfo is not None)

mins = _minutes_since_midnight(ny_dt)
ok("ict_sessions._minutes_since_midnight", mins == 9 * 60)

sess_mon = classify_session(mon_ts)
sess_sat = classify_session(sat_ts)
ok("ict_sessions.classify_session weekday executable", sess_mon.get("session") == "NY_AM_KILLZONE" and sess_mon.get("is_executable_window") is True)
ok("ict_sessions.classify_session weekend blocked", sess_sat.get("session") == "NY_AM_KILLZONE" and sess_sat.get("is_executable_window") is False and sess_sat.get("is_weekend") is True)

ovr = compute_overnight_range(session_data, session_data["timestamps"][-1])
ok("ict_sessions.compute_overnight_range", isinstance(ovr, dict))

prose = session_prose(sat_ts)
ok("ict_sessions.session_prose", isinstance(prose, str) and len(prose) > 10)

# ─────────────────────────────────────────────────────────────
# human_trades_backtest
# ─────────────────────────────────────────────────────────────
class FakeDM:
    def __init__(self, data):
        self.data = data
    def get_ohlcv(self, symbol, timeframe, limit, output_format="dict"):
        return self.data

class FakeBrain:
    def __init__(self, data):
        self.data_manager = FakeDM(data)

trade_data = mk_data(
    opens=[100,100,101,104,103,102],
    highs=[100.5,101.2,104.5,106.0,104.0,103.0],
    lows=[99.5,99.8,100.5,103.2,101.8,101.0],
    closes=[100.0,101.0,104.0,103.6,102.2,101.4],
    start_ts=int(datetime.datetime(2025, 9, 8, 14, 0, tzinfo=UTC).timestamp() * 1000),
)
brain_ok = FakeBrain(trade_data)
outcome_ok = compute_trade_outcome(brain_ok, "BTC/USDT", trade_data["timestamps"][0], 100.0, 98.0, 104.0, False, max_days=2)
ok("human_trades_backtest.compute_trade_outcome trade path", isinstance(outcome_ok, dict) and outcome_ok.get("outcome") in {"SL_HIT", "BREAK_EVEN_HIT", "TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN", "DYNAMIC_TRAIL_HIT", "OPEN", "ORDER_INVALIDATED_BEFORE_FILL", "ENTRY_NEVER_HIT"})

invalid_data = mk_data(
    opens=[101.5,101.2,101.0,100.7],
    highs=[101.8,101.4,101.1,100.9],
    lows=[100.8,100.4,99.8,99.6],
    closes=[101.1,99.9,100.2,100.0],
    start_ts=int(datetime.datetime(2025, 9, 8, 14, 0, tzinfo=UTC).timestamp() * 1000),
)
brain_bad = FakeBrain(invalid_data)
outcome_bad = compute_trade_outcome(brain_bad, "BTC/USDT", invalid_data["timestamps"][0], 105.0, 100.0, 110.0, False, max_days=2)
ok("human_trades_backtest.compute_trade_outcome invalidation path", outcome_bad.get("outcome") in {"ORDER_INVALIDATED_BEFORE_FILL", "ENTRY_NEVER_HIT"})

print("\n" + "=" * 72)
print(f"TOTAL PASSED: {PASSED}")
print(f"TOTAL FAILED: {FAILED}")
print("=" * 72)
if FAILED:
    raise SystemExit(1)
