
def compute_trade_outcome(brain, symbol, publish_ts, entry, sl, tp, is_short, max_days=25):
    from ict_math_engine import (
        check_order_invalidated_before_fill,
        simulate_managed_trade_outcome,
    )
    try:
        start_ts = publish_ts
        end_ts = start_ts + max_days * 24 * 3600 * 1000

        def _fetch_5m_fwd(b, sym, st, en):
            data = b.data_manager.get_ohlcv(sym, "5m", 35000, output_format="dict")
            if not data or not data.get("closes"):
                return None
            idx = [i for i, t in enumerate(data["timestamps"]) if st <= t <= en]
            if not idx:
                return None
            return {
                "timestamps": [data["timestamps"][i] for i in idx],
                "opens": [data["opens"][i] for i in idx],
                "highs": [data["highs"][i] for i in idx],
                "lows": [data["lows"][i] for i in idx],
                "closes": [data["closes"][i] for i in idx],
            }

        data = _fetch_5m_fwd(brain, symbol, start_ts, end_ts)
        # إذا كانت الداتا لا تغطي الصفقة بسبب أنها قديمة جداً (> 8000 شمعة 5م)
        # نستخدم 15m لجلبها لضمان تغطية الصفقات البشرية القديمة
        if not data:
            data = brain.data_manager.get_ohlcv(symbol, "15m", 8000, output_format="dict")
            if not data or not data.get("closes"):
                return {"error": "NO_DATA"}
            idx = [i for i, t in enumerate(data["timestamps"]) if start_ts <= t <= end_ts]
            if not idx:
                return {"error": "NO_DATA"}
            data = {
                "timestamps": [data["timestamps"][i] for i in idx],
                "opens": [data["opens"][i] for i in idx],
                "highs": [data["highs"][i] for i in idx],
                "lows": [data["lows"][i] for i in idx],
                "closes": [data["closes"][i] for i in idx],
            }

        timestamps = data["timestamps"]
        highs = data["highs"]
        lows = data["lows"]
        opens = data.get("opens", data["closes"])
        closes = data["closes"]

        result = {"candles_checked": len(closes)}

        entry_idx = None
        for i in range(len(closes)):
            if lows[i] <= entry <= highs[i]:
                entry_idx = i
                break

        # ⚠️ من دستور مايكل نفسه بالمشروع: إذا انكسر الأساس الهيكلي
        # (body close through) قبل تفعيل الأمر، فالنتيجة الصحيحة ليست
        # ENTRY_NEVER_HIT بل ORDER_INVALIDATED_BEFORE_FILL.
        invalidation = check_order_invalidated_before_fill(
            highs, lows, closes, opens, timestamps,
            start_idx=0, entry_idx=entry_idx, sl_price=sl, is_long=(not is_short)
        )
        if invalidation.get("invalidated"):
            result.update({
                "entry_hit": False,
                "outcome": "ORDER_INVALIDATED_BEFORE_FILL",
                "pnl_pct": 0.0,
                "exit_price": None,
                "exit_time_ms": invalidation.get("invalidation_time_ms"),
                "invalidation_idx": invalidation.get("invalidation_idx"),
                "invalidation_time_ms": invalidation.get("invalidation_time_ms"),
                "invalidation_close_price": invalidation.get("invalidation_close_price"),
                "reason": invalidation.get("reason"),
            })
            return result

        if entry_idx is None:
            result["entry_hit"] = False
            result["outcome"] = "ENTRY_NEVER_HIT"
            result["pnl_pct"] = 0.0
            return result

        result["entry_hit"] = True

        # ⚠️ توحيد مع المرجع الرسمي للمشروع: إدارة 50% TP1 + 50% runner
        # مع BE + structure trail (لا 80% القديمة).
        sim = simulate_managed_trade_outcome(
            data,
            entry_price=entry,
            sl_price=sl,
            tp1_price=tp,
            tp2_info={"mode": "OPEN_TRAILING", "detail": "single-target legacy wrapper"},
            is_short=is_short,
        )

        classification = sim.get("classification")
        final_exit_reason = sim.get("final_exit_reason")

        # نحافظ على مفاتيح legacy حتى لا نكسر السكربتات المحيطة، لكن
        # القيم الآن مشتقة من المحرك الرسمي لا من منطق 80/20 القديم.
        if classification == "LOSS":
            outcome_code = "SL_HIT"
        elif classification == "WIN_PARTIAL":
            outcome_code = "TP1_THEN_BE"
        elif classification == "WIN_TRAIL":
            outcome_code = "DYNAMIC_TRAIL_HIT"
        elif classification == "OPEN_AFTER_TP1":
            outcome_code = "PARTIAL_TP_HIT_THEN_OPEN"
        elif classification == "NEITHER_HIT_WITHIN_WINDOW":
            outcome_code = "OPEN"
        elif classification == "ENTRY_NEVER_HIT":
            outcome_code = "ENTRY_NEVER_HIT"
        else:
            # WIN_FULL غير متوقع هنا لأننا نمرّر OPEN_TRAILING بدل TP2 رقمي،
            # لكن لو ظهر لأي سبب نعتبره مكسباً مُداراً لا خسارة.
            outcome_code = "DYNAMIC_TRAIL_HIT"

        favorable = min(lows[entry_idx:]) if is_short else max(highs[entry_idx:])

        result.update({
            "outcome": outcome_code,
            "classification": classification,
            "tp1_hit": bool(sim.get("tp1_hit")),
            "exit_price": sim.get("final_exit_price"),
            "exit_time_ms": sim.get("final_exit_time"),
            "final_exit_reason": final_exit_reason,
            "max_favorable_excursion": favorable,
            "pnl_pct": sim.get("pnl_pct_blended", 0.0),
            "pnl_pct_blended": sim.get("pnl_pct_blended", 0.0),
            "trail_history": sim.get("trail_history", []),
        })
        return result
    except Exception as e:
        return {"error": str(e)}

